// Arguments passed into this controller can be accessed via the `$.args` object directly or:
var args = $.args;
 
var utils = require("utils");
utils.addFloatingButton({
	view : $.mainScreen
});
